#!/usr/bin/env bash
# Builds a debug APK without Android Studio.
# Needs: JDK 17+ and the Android SDK (command-line tools are enough).
set -e

if ! command -v java >/dev/null 2>&1; then
  echo "Java not found. Install JDK 17 or newer first."
  exit 1
fi

if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "Set ANDROID_HOME to your Android SDK folder, for example:"
  echo "  export ANDROID_HOME=\$HOME/Android/Sdk"
  exit 1
fi

chmod +x ./gradlew
./gradlew assembleDebug

echo
echo "Done. Your APK is at: app/build/outputs/apk/debug/app-debug.apk"
