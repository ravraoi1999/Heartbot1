package com.heartboard.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private const val ALL_CITIES = "All cities"

// ---------------------------------------------------------------- Age gate

@Composable
fun AgeGateScreen(onConfirm: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "HeartBoard",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Meet people nearby through simple classified-style ads. HeartBoard is for adults only, so you must be 18 or older to continue.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onConfirm) { Text("I am 18 or older") }
    }
}

// ------------------------------------------------------------------ Browse

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    onOpenAd: (Int) -> Unit,
    onPost: () -> Unit,
    onSafety: () -> Unit
) {
    var city by rememberSaveable { mutableStateOf(ALL_CITIES) }
    var query by rememberSaveable { mutableStateOf("") }
    var category by remember { mutableStateOf<Category?>(null) }
    var cityMenu by remember { mutableStateOf(false) }

    val filtered = Store.ads.filter { ad ->
        ad.id !in Store.reported &&
            (city == ALL_CITIES || ad.city == city) &&
            (category == null || ad.category == category) &&
            (query.isBlank() ||
                ad.title.contains(query, ignoreCase = true) ||
                ad.description.contains(query, ignoreCase = true))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("HeartBoard") },
                actions = {
                    Box {
                        TextButton(onClick = { cityMenu = true }) {
                            Icon(Icons.Default.LocationOn, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(city)
                        }
                        DropdownMenu(
                            expanded = cityMenu,
                            onDismissRequest = { cityMenu = false }
                        ) {
                            (listOf(ALL_CITIES) + Store.cities).forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(c) },
                                    onClick = {
                                        city = c
                                        cityMenu = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = onSafety) {
                        Icon(Icons.Default.Info, contentDescription = "Safety tips")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onPost,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Post ad") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search ads") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = category == null,
                        onClick = { category = null },
                        label = { Text("All") }
                    )
                }
                items(Category.entries) { c ->
                    FilterChip(
                        selected = category == c,
                        onClick = { category = c },
                        label = { Text(c.label) }
                    )
                }
            }
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No ads match your filters yet.")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { ad ->
                        AdCard(ad = ad, onClick = { onOpenAd(ad.id) })
                    }
                }
            }
        }
    }
}

@Composable
fun AdCard(ad: Ad, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                ad.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "${ad.posterName}, ${ad.age} · ${ad.city} · ${ad.category.label}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                ad.description,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                ad.postedLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

// ------------------------------------------------------------- Ad details

@Composable
fun SafetyBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(
                "Meet in a public place, tell a friend, never send money, and never share OTPs or bank details.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdDetailScreen(adId: Int, onBack: () -> Unit, onMessage: () -> Unit) {
    val ad = Store.ads.firstOrNull { it.id == adId }
    var showReport by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ad details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (ad == null) {
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("This ad is no longer available.")
            }
        } else {
            Column(
                Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    ad.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "${ad.posterName}, ${ad.age} · ${ad.city}",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    "${ad.category.label} · ${ad.postedLabel}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(Modifier.height(16.dp))
                Text(ad.description, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(16.dp))
                SafetyBanner()
                Spacer(Modifier.height(16.dp))
                Button(onClick = onMessage, modifier = Modifier.fillMaxWidth()) {
                    Text("Send message")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { showReport = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Report this ad")
                }
            }

            if (showReport) {
                AlertDialog(
                    onDismissRequest = { showReport = false },
                    title = { Text("Report this ad?") },
                    text = {
                        Text("The ad will be hidden from your feed. In a live version, reports would go to moderators.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            Store.reported.add(ad.id)
                            showReport = false
                            onBack()
                        }) { Text("Report") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showReport = false }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}

// ----------------------------------------------------------------- Post ad

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostAdScreen(onBack: () -> Unit, onPosted: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(Category.DATING) }
    var city by remember { mutableStateOf(Store.cities.first()) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Post an ad") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Display name (first name or nickname)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ageText,
                onValueChange = { v -> ageText = v.filter { it.isDigit() }.take(2) },
                label = { Text("Age (must be 18+)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Category", style = MaterialTheme.typography.labelLarge)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Category.entries.forEach { c ->
                    FilterChip(
                        selected = category == c,
                        onClick = { category = c },
                        label = { Text(c.label) }
                    )
                }
            }

            Text("City", style = MaterialTheme.typography.labelLarge)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Store.cities.forEach { c ->
                    FilterChip(
                        selected = city == c,
                        onClick = { city = c },
                        label = { Text(c) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            val message = error
            if (message != null) {
                Text(message, color = MaterialTheme.colorScheme.error)
            }
            Text(
                "Don't put phone numbers, home addresses or payment details in your ad. People can contact you through in-app messages.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )

            Button(
                onClick = {
                    val age = ageText.toIntOrNull()
                    val problem = when {
                        name.isBlank() -> "Enter a display name."
                        age == null || age < 18 -> "You must be 18 or older to post."
                        title.trim().length < 5 -> "Title needs at least 5 characters."
                        description.trim().length < 20 -> "Description needs at least 20 characters."
                        else -> null
                    }
                    error = problem
                    if (problem == null && age != null) {
                        Store.addAd(
                            title = title.trim(),
                            description = description.trim(),
                            category = category,
                            city = city,
                            age = age,
                            posterName = name.trim()
                        )
                        onPosted()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Publish ad")
            }
        }
    }
}

// -------------------------------------------------------------------- Chat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(adId: Int, onBack: () -> Unit) {
    val ad = Store.ads.firstOrNull { it.id == adId }
    val messages = Store.messagesFor(adId)
    var draft by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ad?.posterName ?: "Chat") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize()
        ) {
            Text(
                "Demo mode: messages stay on this device and nobody receives them. A live version needs a server.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(12.dp)
            )
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { m ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.fromMe) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (m.fromMe) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                m.text,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a message") },
                    maxLines = 3
                )
                IconButton(onClick = {
                    if (draft.isNotBlank()) {
                        Store.send(adId, draft.trim())
                        draft = ""
                    }
                }) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Safety

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyScreen(onBack: () -> Unit) {
    val tips = listOf(
        "Meet first in a busy public place, and tell someone you trust where you're going.",
        "Never send money, gift cards or \"registration fees\" to someone you haven't met.",
        "Don't share OTPs, bank details or ID documents with anyone.",
        "Be wary if someone pushes you to move to another app quickly or refuses a video call.",
        "Never send intimate photos or videos. They can be used to blackmail you.",
        "Report suspicious ads using the Report button on the ad.",
        "If you're being scammed or blackmailed in India, call 1930 or report at cybercrime.gov.in."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Safety tips") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            tips.forEach { tip ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(tip, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}
