package com.heartboard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { HeartBoardApp() }
    }
}

private val HeartColors = lightColorScheme(
    primary = Color(0xFFC2185B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E3),
    onPrimaryContainer = Color(0xFF3E001D),
    secondaryContainer = Color(0xFFFCE4EC),
    onSecondaryContainer = Color(0xFF3E001D),
    tertiaryContainer = Color(0xFFFFF3E0),
    onTertiaryContainer = Color(0xFF3B2A00)
)

@Composable
fun HeartBoardApp() {
    MaterialTheme(colorScheme = HeartColors) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            var isAdult by rememberSaveable { mutableStateOf(false) }
            if (!isAdult) {
                AgeGateScreen(onConfirm = { isAdult = true })
            } else {
                AppNav()
            }
        }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val idArg = listOf(navArgument("id") { type = NavType.IntType })

    NavHost(navController = nav, startDestination = "browse") {
        composable("browse") {
            BrowseScreen(
                onOpenAd = { id -> nav.navigate("ad/$id") },
                onPost = { nav.navigate("post") },
                onSafety = { nav.navigate("safety") }
            )
        }
        composable("ad/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getInt("id") ?: -1
            AdDetailScreen(
                adId = id,
                onBack = { nav.popBackStack() },
                onMessage = { nav.navigate("chat/$id") }
            )
        }
        composable("chat/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getInt("id") ?: -1
            ChatScreen(adId = id, onBack = { nav.popBackStack() })
        }
        composable("post") {
            PostAdScreen(
                onBack = { nav.popBackStack() },
                onPosted = { nav.popBackStack() }
            )
        }
        composable("safety") {
            SafetyScreen(onBack = { nav.popBackStack() })
        }
    }
}
