# HeartBoard

A classifieds-style dating and meetups app for Android (Kotlin + Jetpack Compose).
Browse ads by city and category, search, post an ad, message the poster, report ads, and read safety tips.
It has an 18+ gate on launch.

This is a working **demo**: data is in memory and messages stay on the device. See "Making it real" below.

## Build the APK (pick one, no Android Studio needed)

**A. In the cloud with GitHub Actions (nothing to install)**
1. Create a new GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, and run it (it also runs on every push).
3. When it finishes, download `HeartBoard-debug-apk` from the run page and unzip it to get `app-debug.apk`.

**B. On your own computer from the command line**
1. Install JDK 17+ and the Android SDK command-line tools, then set `ANDROID_HOME`.
2. Run `./build.sh` (macOS/Linux) or `gradlew.bat assembleDebug` (Windows).
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

**C. With Android Studio (optional)**
Open this folder, then Build > Build Bundle(s) / APK(s) > Build APK(s).

To install: copy the APK to your phone and allow "install unknown apps" for your file manager.

## Making it real

A real classifieds-dating service needs more than this app:
- A backend (for example Firebase or Supabase) for accounts, ads and messages.
- Phone or email verification, and real age verification.
- Photo uploads with automated and human moderation.
- Reporting and blocking tools, plus a team to act on reports.
- Scam and spam detection, rate limits, a privacy policy and terms of service.
- A signed release build (generate a keystore and keep it safe) before publishing to the Play Store.
