package com.heartboard.app

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf

enum class Category(val label: String) {
    DATING("Dating"),
    FRIENDS("Friends"),
    ACTIVITY("Activity partners"),
    CHAT("Chat"),
    EVENTS("Events")
}

data class Ad(
    val id: Int,
    val title: String,
    val description: String,
    val category: Category,
    val city: String,
    val age: Int,
    val posterName: String,
    val postedLabel: String
)

data class ChatMessage(val fromMe: Boolean, val text: String)

/**
 * In-memory demo data. Everything resets when the app process is killed.
 * A real version needs a backend (see README).
 */
object Store {
    val cities = listOf(
        "Mumbai", "Delhi", "Bengaluru", "Chennai",
        "Hyderabad", "Kolkata", "Pune", "Coimbatore"
    )

    val ads = mutableStateListOf(
        Ad(
            1, "Coffee and long walks?",
            "Software engineer who loves filter coffee, books and weekend treks. Looking to meet someone genuine for a relaxed first meet in a public cafe.",
            Category.DATING, "Bengaluru", 27, "Arjun", "2 hours ago"
        ),
        Ad(
            2, "New in town, looking for friends",
            "Moved here for work last month and don't know many people yet. Happy to explore cafes, markets and weekend plans with new friends.",
            Category.FRIENDS, "Pune", 24, "Meera", "5 hours ago"
        ),
        Ad(
            3, "Badminton partner on weekends",
            "Intermediate player looking for a regular partner for Saturday morning games. Courts near Gachibowli. All genders welcome.",
            Category.ACTIVITY, "Hyderabad", 29, "Kiran", "Yesterday"
        ),
        Ad(
            4, "Book lover seeking thoughtful conversation",
            "Reading a lot of fiction lately and would love to chat about books, music and life with someone curious and kind.",
            Category.CHAT, "Chennai", 31, "Divya", "Yesterday"
        ),
        Ad(
            5, "Sunday trek group, 6 spots left",
            "Easy day trek this Sunday, starting at 6 AM from the city. Meet at the group point, carry water, and bring good shoes.",
            Category.EVENTS, "Mumbai", 26, "Rohan", "2 days ago"
        ),
        Ad(
            6, "Looking for something serious",
            "Teacher who enjoys cooking and classic movies. I'm looking for a respectful, open-minded person who wants a real relationship.",
            Category.DATING, "Delhi", 33, "Neha", "2 days ago"
        ),
        Ad(
            7, "Street food walk meetup",
            "Monthly food walk through the old city lanes. Come alone or bring friends. We split nothing, everyone pays for their own food.",
            Category.EVENTS, "Kolkata", 28, "Sourav", "3 days ago"
        ),
        Ad(
            8, "Filter coffee and board games",
            "Hosting a casual board games afternoon at a cafe. Beginners welcome, and I'll bring a few games.",
            Category.FRIENDS, "Coimbatore", 25, "Pooja", "4 days ago"
        )
    )

    /** Ad ids the user has reported; hidden from the feed. */
    val reported = mutableStateListOf<Int>()

    private val chats = mutableStateMapOf<Int, List<ChatMessage>>()

    fun messagesFor(adId: Int): List<ChatMessage> = chats[adId] ?: emptyList()

    fun send(adId: Int, text: String) {
        chats[adId] = messagesFor(adId) + ChatMessage(fromMe = true, text = text)
    }

    fun addAd(
        title: String,
        description: String,
        category: Category,
        city: String,
        age: Int,
        posterName: String
    ) {
        val nextId = (ads.maxOfOrNull { it.id } ?: 0) + 1
        ads.add(
            0,
            Ad(nextId, title, description, category, city, age, posterName, "Just now")
        )
    }
}
